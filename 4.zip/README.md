# Club Pádel Verde

Proyecto Intermodular 2º DAW  
Sistema de gestión de reservas de pistas de pádel.

Tecnologías:
- PHP 8.2 (MVC)
- MySQL
- HTML, CSS, JavaScript
- Bootstrap

